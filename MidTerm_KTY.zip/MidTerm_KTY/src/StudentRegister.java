import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

class student{
	String name;
	String id;
	String grade;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id=id;
	}
	public String getgrade() {
		return grade;
	}
	public void setgrade(String grade) {
		this.grade=grade;
	}
	public student(String name, String id, String grade) {
		super();  
		this.name=name;
		this.id=id;
		this.grade=grade;
	}// **
}

public class StudentRegister extends JFrame {
	ArrayList<student> list = new ArrayList<>();  
	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private JLabel label4;
	private JTextField field1;
	private JTextField field2;
	private JTextField field3;
	
	private JTextField textField_1;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentRegister frame = new StudentRegister();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public  StudentRegister() {
		JPanel panel=new JPanel();
		add(panel);
		setTitle("덕성여대 화이팅!");
		setSize(300,200);
		
		
		JLabel label1=new JLabel("학생 등록하기");
		JLabel label2=new JLabel("이름");
		
		JLabel label3=new JLabel("학번");
		JLabel label4=new JLabel("성적");
		JTextField field1=new JTextField(15);
		JTextField field2=new JTextField(15);
		JTextField field3=new JTextField(15);
		
		
		
		
		
		panel.add(label1);
		panel.add(label2);
		panel.add(field1);
		panel.add(label3);
		panel.add(field2);
		
		panel.add(label4);
		panel.add(field3);
	
	
		
		JButton button1=new JButton("등록하기");
		JButton button2=new JButton("취소");
		
		panel.add(button1);
		panel.add(button2);
		
		setVisible(true);
		
		
		
		 button1.addActionListener(e->{
			 
		 
			String name = field1.getName();
			String id = field2.getid;
			String grade = field3.getgrade();
			list.add(new student(name, id, grade));
			System.out.print(list);
		});
		
		
	}
}
		
		
	


