
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ManagementSystem {
    public static void main(String[] args) {
        JFrame frame = new JFrame("학생 성적 계산기");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

      
        ArrayList<Integer> scores = new ArrayList<>();

        
        JPanel panel = new JPanel();
        frame.add(panel);

        JLabel scoreLabel = new JLabel("성적:");
        JTextField scoreField = new JTextField(5);
        JButton addButton = new JButton("입력");
        JButton calculateButton = new JButton("평균계산");
        JTextArea resultArea = new JTextArea(5, 20);

      
        panel.add(scoreLabel);
        panel.add(scoreField);
        panel.add(addButton);
        panel.add(calculateButton);
        panel.add(resultArea);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                String scoreText = scoreField.getText();
               
                    int score = Integer.parseInt(scoreText);
                    scores.add(score);
                    scoreField.setText("");
              
            }
        });

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                if (scores.isEmpty()) {
                    resultArea.setText("아직 성적이 입력되지 않았습니다.");
                } else {
                    int sum = 0;
                    for (int score : scores) {
                        sum += score;
                    }
                    double average = (double) sum / scores.size();
                    resultArea.setText("평균 성적: " + average);
                }
            }
        });

        frame.setVisible(true);
    }
}


